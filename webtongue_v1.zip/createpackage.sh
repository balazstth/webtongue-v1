#!/bin/bash
rm webtongue_v1.zip
zip -r webtongue_v1.zip *
